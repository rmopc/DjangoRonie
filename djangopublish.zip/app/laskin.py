def plus(a, b):
    return int(a) + int(b)